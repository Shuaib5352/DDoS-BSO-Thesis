# 🎯 تشغيل تطبيق DDoS-BSO Tespiti

## 🖱️ طرق التشغيل

### 1️⃣ **من سطح المكتب (الطريقة السهلة)**
- ابحث عن أيقونة **"DDoS-BSO Tespiti"** على سطح المكتب
- انقر عليها **نقرة مزدوجة** ببطء
- سينتظر التطبيق 5 ثوانٍ لتحضير الخادم
- ستفتح نافذة التطبيق على سطح الحاسوب

### 2️⃣ **من قائمة ابدأ (Start Menu)**
- انقر على **"ابدأ"** في الزاوية السفلية اليسرى
- ابحث عن **"DDoS-BSO Tespiti"**
- انقر عليها لتشغيل التطبيق

### 3️⃣ **من سطر الأوامر (خيار متقدم)**
```powershell
cd C:\Users\imiss\Desktop\DDoS-BSO-Thesis
.\start-app.bat
```

---

## ⚙️ ما يحدث عند التشغيل

```
1. ✅ إيقاف أي عمليات سابقة
         ↓
2. ✅ بدء خادم Next.js على localhost:8888
         ↓
3. ✅ انتظار 5 ثوانٍ
         ↓
4. ✅ فتح نافذة Electron
         ↓
5. ✅ عرض تطبيق DDoS-BSO Tespiti
```

---

## 🎨 معلومات الأيقونة

| المعلومة | القيمة |
|---------|--------|
| **الاسم** | DDoS-BSO Tespiti |
| **الوصف** | DDoS Saldırısı Tespiti - BSO-Hibrit Framework |
| **الملف** | start-app.bat |
| **الأيقونة** | icon.ico (256×256 pixels) |
| **الموقع** | C:\Users\imiss\Desktop\DDoS-BSO Tespiti.lnk |

---

## ⚡ نصائح مهمة

✅ **عند التشغيل:**
- يجب أن يكون الإنترنت متصلاً (أو على الأقل localhost يعمل)
- انتظر ظهور النافذة (قد تستغرق 5-10 ثوانٍ)
- لا تغلق نافذة الـ command prompt (تعمل في الخلفية)

⚠️ **إذا لم يعمل:**
- تأكد من أن المنفذ 8888 متاح
- حاول إعادة التشغيل يدويًا
- تحقق من أن Node.js مثبت على الجهاز

❌ **لإغلاق التطبيق:**
1. اغلق نافذة Electron
2. اغلق نافذة command prompt
3. أو اضغط `Ctrl+C` في نافذة الـ command prompt

---

## 📂 الملفات المتعلقة

```
C:\Users\imiss\Desktop\DDoS-BSO-Thesis\
├── start-app.bat                    ← ملف التشغيل الرئيسي
├── create-shortcut.vbs              ← إنشاء الاختصار
├── create-startmenu.vbs             ← إنشاء دخول Start Menu
├── public/
│   ├── electron.js                  ← تطبيق Electron
│   ├── icon.ico                     ← الأيقونة
│   └── ...
└── ...
```

---

## 🔧 إضافة اختصار إضافي (اختياري)

إذا كنت تريد إضافة اختصار إضافي:

```powershell
cd C:\Users\imiss\Desktop\DDoS-BSO-Thesis
cscript.exe create-shortcut.vbs      # سطح المكتب
cscript.exe create-startmenu.vbs     # Start Menu
```

---

**🎉 جاهز للعمل! انقر على الأيقونة الآن وتمتع بتجربة DDoS-BSO Tespiti على سطح الحاسوب!**
